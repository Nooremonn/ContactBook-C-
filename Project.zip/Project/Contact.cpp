#include "Contact.h"
#include"Address.h"
#include<iostream>

// default constructor for class to intialize all values with null values
Contact::Contact() : address(new Address()), first_name(""), last_name(""), email_address(""), 
mobile_number(""), contact_id("") {}

// parametrized constructor to intialize all values with give values in parameters
Contact::Contact(std::string& first_name, std::string& last_name, std::string& mobile_number,
	std::string& email_address,std::string& contact_id, Address* address)
{
	this->first_name = first_name;
	this->last_name = last_name;
	this->mobile_number = mobile_number;
	this->email_address = email_address;
	this->contact_id = contact_id;
	this->address = address;
}

// function to copy contact and retrun a deep copy of contact
Contact* Contact::CopyContact()
{
	Contact* new_copy_contact = this;

	return new_copy_contact;
}

// function to check if two contacts are equal or not along with their address
bool Contact::Equals(const Contact& contact) const
{
	return (this->first_name == contact.first_name
		&& this->last_name == contact.last_name
		&& this->email_address == contact.email_address
		&& this->mobile_number == contact.mobile_number
		&& this->contact_id == contact.contact_id
		&& this->address->Equals(*contact.address));


}
// setter Functions to set values for each attributes
void Contact::SetFirstName(const std::string& first_name) { this->first_name = first_name; }    
void Contact::SetLastName(const std::string& last_name) { this->last_name = last_name; }
void Contact::SetMobileNumber(const std::string& mobile_number) { this->mobile_number = mobile_number; }
void Contact::SetEmailAddress(const std::string& email_address) { this->email_address = email_address; }
void Contact::SetAddress(Address* address) { this->address = address; }
void Contact::SetContactID(const std::string& contact_id) { this->contact_id = contact_id; }

// getter Functions to get values
std::string Contact::GetFirstName() const { return this->first_name; }
std::string Contact::GetLastName() const { return this->last_name; }
std::string Contact::GetMobileNumber() const { return this->mobile_number; }
std::string Contact::GetEmailAddress() const { return this->email_address; }
std::string Contact::GetContactID() const { return contact_id; }
Address Contact::GetAddress() const { return *address; }

// overloaded operator for input contact attributes
std::istream& operator>>(std::istream& input, Contact& contacts)
{
	std::cout << "Enter Contact ID: "; std::getline(input, contacts.contact_id);
	std::cout << "Enter First Name: "; std::getline(input, contacts.first_name);
	std::cout << "Enter Last Name: "; std::getline(input, contacts.last_name);
	contacts.mobile_number = " ";
	while (contacts.mobile_number.size() < 11 || contacts.mobile_number.size() > 11)
	{
		std::cout << "Enter Mobile Number(must be 11 digits): "; std::getline(input, contacts.mobile_number);
	}
	std::cout << "Enter Email Address: "; std::getline(input, contacts.email_address);

	Address* new_temp_address = new Address();
	input >> *new_temp_address;
	contacts.SetAddress(new_temp_address);

	return input;
}

// overloaded operator to show contact attributes on console
std::ostream& operator<< (std::ostream& output, Contact& contacts)
{
	output << "[" << contacts.contact_id << "][" << contacts.first_name << "][" << contacts.last_name << "][" <<
		contacts.email_address << "][" << contacts.mobile_number << "]" << std::endl;
	output << *contacts.address << std::endl;
	return output;
}