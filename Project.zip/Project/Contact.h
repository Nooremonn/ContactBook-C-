#pragma once

#ifndef BASIC_LIB
#define BASIC_LIB
#include <iostream>
#include <string>
#endif // !BASIC_LIB

#include "Address.h"


class Contact {
private:
	std::string first_name;
	std::string last_name;
	std::string mobile_number;
	std::string email_address;
	std::string contact_id;
	Address* address;

public:
	bool Equals(const Contact& contact) const;
	Contact* CopyContact();

	// overloaded function to input and ouptut data
	friend std::istream& operator>>(std::istream& input, Contact& contacts);
	friend std::ostream& operator<< (std::ostream& output, Contact& contacts);

	// setter Functions
	void SetFirstName(const std::string& first_name);
	void SetLastName(const std::string& last_name);
	void SetMobileNumber(const std::string& mobile_number);
	void SetEmailAddress(const std::string& email_address);
	void SetAddress(Address* address);
	void SetContactID(const std::string& contact_id);

	// getter Functions
	std::string GetFirstName() const;
	std::string GetLastName() const;
	std::string GetMobileNumber() const;
	std::string GetEmailAddress() const;
	std::string GetContactID() const;
	Address GetAddress() const;

	Contact();
	Contact(std::string& first_name, std::string& last_name, std::string& mobile_number,
		std::string& email_address,std::string& contact_id, Address* address);
};
