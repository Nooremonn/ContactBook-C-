#pragma once
#include "Address.h"
#include "Contact.h"
#include "Groups.h"

#ifndef BASIC_LIB
#define BASIC_LIB

#include <iostream>
#include <string>
#endif // !BASIC_LIB


class ContactsBook {
private:
	Group* groups_list;
	Contact* contacts_list; // array of contacts
	int size_of_contacts;   // storage limit
	int contacts_count;     // total contacts 
	int size_of_group;
	int groups_count;

public:
	ContactsBook();                                     // default constructor
	ContactsBook(const int& contact_size);              // parametrized constructor
	void CreateGroupList(const int& group_num);
	void AddContact(const Contact& contact);
	void AddGroup(const Group& groups);
	int TotalContact() const;
	int TotalGroups() const;
	void AddContactInGroup(const int& group_num, const int& contact_num);
	void CheckContactInGroupList(const int& contact_num);
	void DeleteGroupFromList(const int& group_num);

	Contact* GetCopy() const;
	Group GetGroup(int& group_num) const;

	// function to print ID of contact
	void PrintID() const;
	void PrintContact(int num) const;
	void UpdataContact(int contact_num);
	void DeleteContact(int contact_num);
	void PrintGroupName() const;
	void RemoveContactFromGroup( int& member_num, const int& group_num);

	/*ContactsBook(int size_of_list);*/

	void PrintContactSorted(const std::string& choice); // Only two choices first_name or last_name
	void MergeDuplicate(); 

	// functions to read and save data to file 
	void LoadFromFile(const std::string& file_name);
	void LoadGroupFile(const std::string& file_name);
	void SaveToFile(const std::string& file_name);
	void SaveGroupToFile(const std::string& file_name);


	// function to peform advance search in list
	void AdvanceSearch(const std::string& string_to_search);

	friend std::ostream& operator << (std::ostream& output, ContactsBook book);

private:
	bool Full();
	void ResizeList();
	void ResizeGroupList();
	void SortContactsList(Contact*& contacts_list, std::string choice);
};
