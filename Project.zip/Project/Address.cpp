#include "Address.h"

// copy constructor
Address::Address(const Address& address)
{
	this->house = address.house;
	this->city = address.city;
	this->country = address.country;
	this->street = address.street;
}

// function to check if two address objects are equal or not
bool Address::Equals(const Address& address) const {
	return this->city == address.city
		&& this->country == address.country
		&& this->house == address.house
		&& this->street == address.street;
}

// function to print address's object values
void Address::PrintAddress() const
{
	std::cout << this->house << ", " << this->street << ", "
		<< this->city << ", " << this->country << std::endl;
}

// function to copy address attributes
Address Address::CopyAddress()
{
	Address newaddress = *this;
	return newaddress;
}

// parametrized constructor 
Address::Address(std::string house, std::string street, std::string city, std::string country)
{
	this->house = house;
	this->street = street;
	this->city = city;
	this->country = country;
}

// default constructor
Address::Address()
{
	this->house = this->street = this->city = this->country = " ";
}

// setter  functions
void Address::SetHouse(const std::string& house) { this->house = house; }
void Address::SetStreet(const std::string& street) { this->street = street; }
void Address::SetCity(const std::string& city) { this->city = city; }
void Address::SetCountry(const std::string& country) { this->country = country; }

// getter functions
std::string Address::GetHouse() const { return this->house; }
std::string Address::GetStreet() const { return this->street; }
std::string Address::GetCity() const { return this->city; }
std::string Address::GetCountry() const { return this->country; }

// overloaded operator to print values on console
std::ostream& operator<<(std::ostream& output, Address& address)
{
	output << "\tAddress: ";
	output << "[" << address.house << "][" << address.street << "]["
		<< address.city << "][" << address.country << "]" << std::endl;
	return output;
}

// overloaded constructor to take input values
std::istream& operator>>(std::istream& input, Address& address)
{
	std::cout << "Please enter the address details below:" << std::endl;

	std::cout << "House: ";
	std::getline(std::cin, address.house);

	std::cout << "Street: ";
	std::getline(std::cin, address.street);

	std::cout << "City: ";
	std::getline(std::cin, address.city);

	std::cout << "Country: ";
	std::getline(std::cin, address.country);

	return input;
}