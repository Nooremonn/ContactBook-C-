#pragma once
#include <iostream>
#include <string>


class Address {
private:
	std::string house;
	std::string street;
	std::string city;
	std::string country;

public:
	bool Equals(const Address& address) const;
	void PrintAddress() const;
	Address CopyAddress();

	// overloaded operator to input address and output address
	friend std::istream& operator>>(std::istream& input, Address& address);
	friend std::ostream& operator<<(std::ostream& output, Address& address);

	// setter  functions
	void SetHouse(const std::string& house);
	void SetStreet(const std::string& street);
	void SetCity(const std::string& city);
	void SetCountry(const std::string& country);

	// getter functions
	std::string GetHouse() const;
	std::string GetStreet() const;
	std::string GetCity() const;
	std::string GetCountry() const;

	// parametrized Constructor
	Address(std::string house, std::string street, std::string city, std::string country);

	// default Constructor
	Address();

	// copy constructor
	Address(const Address& address);
};
