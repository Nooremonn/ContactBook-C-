#pragma once
#ifndef BASIC_LIB
#define BASIC_LIB
#include"Contact.h"
#include <iostream>
#include <string>
#include<fstream>
#endif // !BASIC_LIB

using namespace std;

class Group
{
private:
	string group_name;
	string* group_members;
	int total_members;
public:
	Group();
	Group(int total_members);

	void AddMembers(const string& contact);
	int TotalMembers() const;
	void RemoveMember(int & member_num, string id = " ");
	bool CheckMember(string& member_id) const;
	void updateMember(string& old_id, string& new_id);

	void PrintMembers() const;
	void SetGroupName(const string& group_name);
	string GetGroupname() const;

	void SaveToFile(ofstream& write_file);
	void LoadFile(ifstream& load_file);
};
