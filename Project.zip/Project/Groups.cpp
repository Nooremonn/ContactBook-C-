#include"Groups.h"
#include<fstream>
using namespace std;

// default constructor 
Group::Group()
{
	group_name = " ";
	total_members = 0;
	group_members = nullptr /*new string[total_members + 1]*/;
}

// parametrized constructor
Group::Group(int total_members) : total_members(total_members), group_members(new string[total_members]) {}

void Group::AddMembers(const string& contact_id)
{
	group_members[total_members] = contact_id;

	string* new_list = new string[total_members + 2];

	for (int i = 0; i < total_members + 1; i++)
	{
		new_list[i] = group_members[i];
	}
	group_members = new_list;
	total_members++;
}

int Group::TotalMembers() const { return total_members; }
void Group::SetGroupName(const string& group_name) { this->group_name = group_name; }

string Group::GetGroupname() const { return this->group_name; }

void Group::PrintMembers() const
{
	for (int i = 0; i < total_members; i++)
	{
		cout << i + 1 << ". " << group_members[i] << endl;
	}
}

void Group::RemoveMember(int& member_num, string id)
{
	for (int i = 0; i < total_members; i++)
	{
		if (i == member_num || group_members[i] == id)
		{
			group_members[i] = " ";
			for (int j = i; j < total_members - 1; j++)
			{
				swap(group_members[j], group_members[j + 1]);
			}
			total_members--;
		}
	}

}

void Group::updateMember(string& old_id, string& new_id)
{
	for (int i = 0; i < total_members; i++)
	{
		if (group_members[i] == old_id)
		{
			group_members[i] = new_id;
		}
	}
}

bool Group::CheckMember(string& member_id) const
{
	for (int i = 0; i < total_members; i++)
	{
		if (group_members[i] == member_id) return true;
	}
	return false;
}

void Group::SaveToFile(ofstream& write_file)
{
	write_file << total_members << endl;
	write_file << group_name << endl;
	for (int i = 0; i < total_members; i++)
	{
		write_file << group_members[i] << " ";
	}
	write_file << endl;
}

void Group::LoadFile(ifstream& load_file)
{
	load_file >> total_members;
	load_file >> ws;

	getline(load_file, group_name);
	group_members = new string[total_members];

	for (int i = 0; i < total_members; i++)
	{
		load_file >> group_members[i];
	}
}