#include<iostream>
#include"ContactsBook.h"
#include"Groups.h"
using namespace std;

// function to show menu on console
void DriveMenu(int& command)
{
	string options[] = {
	"0. Exit\n",
	"1. Manage Groups\n",
	"2. Add New Contact\n",
	"3. Merge Duplicates\n",
	"4. Print Contacts Sorted\n",
	"5. Print Contacts\n",
	"6. Search Contacts\n",
	"7. Display Count of Contacts\n"
    };

    cout << "Available Commands!" << endl;
	for (int i = 0; i < 8;  i++) {
        cout << options[i];
    }
    cout << endl << "Enter Your Choice: ";
    cin >> command;
    cin.ignore();
}

// menu for Manging contacts
void ContactsManagingMenu(int& command)
{
	cout << "\nSelect following Option: " << endl;
	cout << "0. Go back " << endl;
	cout << "1. View Detail of single contact " << endl;
	cout << "2. Update detail of a Contact" << endl;
	cout << "3. Delete a contact " << endl << endl;
	cout << "Enter your choice: "; cin >> command;
	cin.ignore();
}

// menu for managing groups
void GroupManagingMenu(int& command)
{
	cout << "0. Go Back" << endl;
	cout << "1. Creata a new Group" << endl;
	cout << "2. Add a Contact to Goup" << endl;
	cout << "3. Remove Contact From a Group" << endl;
	cout << "4. View Contact's Group" << endl;
	cout << "5. Delete A group" << endl << endl;
	cout << "Enter You choice: "; cin >> command;
	cin.ignore();
}

// function to add group
Group AddGroup(string& str)
{
	Group group ;
	cout << "Enter Name for Group: "; getline(cin, str);
	group.SetGroupName(str);
	return group;
}

// function to add contact in a goup
void AddContactInGroup(ContactsBook& book_1, int& group_num, int& contact_num)
{
	group_num = -1;
	contact_num = -1;
	cout << "Here's the list of Groups " << endl;
	book_1.PrintGroupName();
	while (group_num < 1 || group_num > book_1.TotalGroups())
	{
		cout << "Enter Group Number to add Contact in Group: ";
		cin >> group_num;
	}
	cout << endl << "Here's the list of Contacts: " << endl;
	book_1.PrintID();
	while (contact_num < 1 || contact_num > book_1.TotalContact())
	{
		cout << "Enter Contact Number to add in Group " << group_num << ": ";
		cin >> contact_num;
	}
	contact_num--;
	group_num--;
	
	book_1.AddContactInGroup(group_num, contact_num);
	cout << "Contact Added in Group Successfully!" << endl;
}

// function to remove contact from group
void RemoveContactFromGroup(ContactsBook& book_1, int& group_num, int& members_num)
{
	cout << "\nHere's the list of Groups: " << endl;
	book_1.PrintGroupName();
	cout << endl << "Enter Group Num: "; cin >> group_num;
	group_num--;
	Group new_group = book_1.GetGroup(group_num);

	cout << "\nHere's the list of Contacts Present in " << new_group.GetGroupname() << "'s Group: \n";
	new_group.PrintMembers();
	members_num = -1;
	while (members_num < 1 || members_num > new_group.TotalMembers())
	{
		cout << endl << "Enter member num to remove: "; cin >> members_num;
	}
	members_num--;
	book_1.RemoveContactFromGroup(members_num, group_num);
	cout << "Memeber removed Successfully!" << endl;
}

// function to show a contact in all group
void ViewContactInGroup(ContactsBook& book_1, int& contact_num)
{
	contact_num = -1;
	cout << "Here's the list of Contacts: " << endl;
	book_1.PrintID();
	cout << endl;
	while (contact_num < 1 || contact_num > book_1.TotalContact()) 
	{
		cout << "Enter Contact Number: "; cin >> contact_num;
	}

	cout << "In following groups, entered contact occured: " << endl;
	book_1.CheckContactInGroupList(contact_num - 1);
}

// function to delte group from contacts book
void DeleteGroup(ContactsBook& book_1, int& group_num)
{
	if (book_1.TotalGroups() == 0)
	{
		cout << "You have already delelted all groups!" << endl; return;
	}
	group_num = -1;

	cout << "Here's the list of Groups: " << endl;
	book_1.PrintGroupName();

	while (group_num < 1 || group_num > book_1.TotalGroups())
	{
		cout << "Enter Group Number to delete from list: "; cin >> group_num;
	}
	book_1.DeleteGroupFromList(group_num - 1);
}

int main()
{
	int command = -1;
	int option_choice ;
	int group_num = 0;
	int total_contacts = 0;
	ContactsBook book_1;
	Contact new_contact;
	Group groups;
	string str;
	
	book_1.LoadFromFile("ContactFile.txt");
	book_1.LoadGroupFile("GroupFile.txt");

	while (command != 0)
	{
		option_choice = -1;
		system("cls");
		DriveMenu(command);

		switch (command)
		{
		case 1:
			GroupManagingMenu(command);
			if (command == 0) cout << "Moving Back" << endl;
			else if (command == 1)
			{
				    book_1.AddGroup(AddGroup(str));
			}
			else if (command == 2) AddContactInGroup(book_1, group_num, total_contacts);
			else if (command == 3) RemoveContactFromGroup(book_1, group_num, total_contacts);
			else if (command == 4) ViewContactInGroup(book_1, total_contacts);
			else if (command == 5) DeleteGroup(book_1, group_num);
			else cout << "Error! Invalid Data " << endl;
			command = -1;

			break;

		case 2:
			cin >> new_contact;
			book_1.AddContact(new_contact);
			cout << "Contact Added Succesfully!" << endl;

			break;

		case 3:

			book_1.MergeDuplicate();
			break;

		case 4:

			while (option_choice <= 0 || option_choice > 2)
			{
				cout << "Enter 1 for First Name and 2 for Last Name to sort: "; cin >> option_choice;
			}
			if (option_choice == 1) book_1.PrintContactSorted("First Name");
			else book_1.PrintContactSorted("Last Name");

			break;

		case 5:

			cout << endl << "Here's the list of Contacts: " << endl;
			book_1.PrintID();

			ContactsManagingMenu(command);
			if (command > 0 && command <= 3)
			{
				while (option_choice <= 0 || option_choice > book_1.TotalContact())
				{
					cout << endl << "Enter contact number: "; cin >> option_choice;
				}
				cin.ignore();
				option_choice -= 1;
			}

			if (command == 1) book_1.PrintContact(option_choice);
			else if (command == 2) book_1.UpdataContact(option_choice);
			else if (command == 3) book_1.DeleteContact(option_choice);

			command = -1;
			break;

		case 6:

			cout << "Enter to Search: "; getline(cin, str);
			book_1.AdvanceSearch(str);

			break;

		case 7:
			cout << "Total Contacts Count are: " << book_1.TotalContact() << endl;
			break;

		case 0:
			cout << "Programm Stopped!" << endl;
			break;
		}
		book_1.SaveToFile("ContactFile.txt");
		book_1.SaveGroupToFile("GroupFile.txt");

		system("pause");


	}
	return 0;
}
